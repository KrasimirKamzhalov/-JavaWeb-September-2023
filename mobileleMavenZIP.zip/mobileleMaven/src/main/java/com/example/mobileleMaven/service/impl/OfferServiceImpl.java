package com.example.mobileleMaven.service.impl;

import com.example.mobileleMaven.model.dto.CreateOfferDTO;
import com.example.mobileleMaven.repository.OfferRepository;
import com.example.mobileleMaven.service.OfferService;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class OfferServiceImpl implements OfferService {
    private final OfferRepository offerRepository;

    public OfferServiceImpl(OfferRepository offerRepository){

        this.offerRepository = offerRepository;
    };
    @Override
    public UUID createOffer(CreateOfferDTO createOfferDTO) {
throw  new UnsupportedOperationException("Coming soon");
    }
}
