package com.example.mobileleMaven.model.dto;

public record CreateOfferDTO (){
}
