package com.example.mobileleMaven.service;

import com.example.mobileleMaven.model.dto.CreateOfferDTO;

import java.util.UUID;

public interface OfferService {

   UUID createOffer(CreateOfferDTO createOfferDTO);
}
