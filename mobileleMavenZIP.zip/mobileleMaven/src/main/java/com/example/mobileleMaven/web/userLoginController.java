package com.example.mobileleMaven.web;

import com.example.mobileleMaven.model.dto.UserLoginDTO;
import com.example.mobileleMaven.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class userLoginController {
    private final UserService userService;

    public userLoginController(UserService userService, UserService userService1) {

        this.userService = userService1;
    }

    @GetMapping("/users/login")
    public String login() {
        return "auth-login";
    }

    @GetMapping("/users/logout")
    public String logout() {
        userService.logoutUser();
        return "index";
    }

    @PostMapping("/users/login")
    public String login(UserLoginDTO userLoginDTO) {
        boolean loginSuccessful = userService.loginUser(userLoginDTO);
        return loginSuccessful ? "index" : "auth-login";
    }
}
