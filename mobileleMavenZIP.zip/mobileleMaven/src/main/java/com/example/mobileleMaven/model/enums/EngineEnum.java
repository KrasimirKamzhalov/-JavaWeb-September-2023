package com.example.mobileleMaven.model.enums;

public enum EngineEnum {
    PETROL,
    DIESEL,
    ELECTRIC,
}
