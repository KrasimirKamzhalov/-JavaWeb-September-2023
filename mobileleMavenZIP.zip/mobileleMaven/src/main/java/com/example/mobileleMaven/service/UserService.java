package com.example.mobileleMaven.service;

import com.example.mobileleMaven.model.dto.UserLoginDTO;
import com.example.mobileleMaven.model.dto.UserRegistrationDTO;

public interface UserService {
    void registerUser(UserRegistrationDTO userRegistrationDTO);

    boolean     loginUser(UserLoginDTO userLoginDTO);

     void logoutUser();

}
