package com.example.mobileleMaven.model.enums;

public enum TransmissionEnum {
    MANUAL,
    AUTOMATIC;

}
