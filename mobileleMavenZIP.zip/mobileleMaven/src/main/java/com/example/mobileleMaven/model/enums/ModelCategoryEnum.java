package com.example.mobileleMaven.model.enums;

public enum ModelCategoryEnum {
    CAR,
    TRUCK,
    MOTORCYCLE;
}
