package com.example.mobileleMaven.repository;

import com.example.mobileleMaven.model.entity.BrandEntity;
import com.example.mobileleMaven.model.entity.OfferEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BrandRepository extends JpaRepository<BrandEntity,Long> {
}
