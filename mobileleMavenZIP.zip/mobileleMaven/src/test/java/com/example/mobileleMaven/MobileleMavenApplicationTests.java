package com.example.mobileleMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileleMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
